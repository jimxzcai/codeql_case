<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title></title>
	<style type="text/css">
        html,body
        {
            overflow:hidden; 
            margin: 0px 0px;
            width: 100%;
            height: 100%;
        }
        iframe,div
        {
            overflow:hidden;
            margin: 0px 0px;
            width: 100%;
            height: 100%;
        }
	</style>
</head>

<script src="./common/jquery-1.11.3.min.js"></script>
<script src="./common/common.js"></script>

<body>
	<div id="test"></div>
</body>
<script type='text/javascript'>

var loadPage = function()
{
    var value = decodeURIComponent(getUrlParam()['a']);
    $("#test")[0].innerHTML = value;
}
loadPage();
</script>
</html>
