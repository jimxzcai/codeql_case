/****
 *
 *  getUrlParam()[key];
 *
****/
function getUrlParam()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}



/****
 *
 *  getParam("key")
 *
****/
function getParam(name,url) 
{
    var r=new RegExp("(\\?|#|&)"+name+"=(.*?)(#|&|$)")
    var m=(url||location.href).match(r);
    var m = location.href.match(r);
    if (!m || m == "") 
    {
        try 
        {
            m = top.location.href.match(r);
        } 
        catch (e) {}
    }
    m = !m ? "" : m[2];
    while (true) 
    {
        var mm = decodeURIComponent(m);
        if (mm === m) 
        {
            break;
        } 
        else 
        {
            m = mm;
        }
    }
    return m;
}
