cd /data/landun/workspace 
# Coverity/Klocwork将通过调用编译脚本来编译您的代码，以追踪深层次的缺陷
# 请使用依赖的构建工具如maven/cmake等写一个编译脚本build.sh
# 确保build.sh能够编译代码
# cd path/to/build.sh
# sh build.sh
echo